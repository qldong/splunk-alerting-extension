#!/bin/sh -x
# -------------------------------------------------------------
# Shell script to send policy violation notifications to Splunk
# -------------------------------------------------------------
../../../jdk/bin/java -Dlog4j.configuration=file:../../conf/log4j.xml -jar ../../lib/splunkClient.jar PolicyViolation "$@"
